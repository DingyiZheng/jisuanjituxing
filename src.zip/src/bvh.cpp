#include "bvh.h"

#include "CGL/CGL.h"
#include "static_scene/triangle.h"

#include <iostream>
#include <stack>

using namespace std;

namespace CGL { namespace StaticScene {

BVHAccel::BVHAccel(const std::vector<Primitive *> &_primitives,
                   size_t max_leaf_size) {

  root = construct_bvh(_primitives, max_leaf_size);

}

BVHAccel::~BVHAccel() {
  if (root) delete root;
}

BBox BVHAccel::get_bbox() const {
  return root->bb;
}

void BVHAccel::draw(BVHNode *node, const Color& c) const {
  if (node->isLeaf()) {
    for (Primitive *p : *(node->prims))
      p->draw(c);
  } else {
    draw(node->l, c);
    draw(node->r, c);
  }
}

void BVHAccel::drawOutline(BVHNode *node, const Color& c) const {
  if (node->isLeaf()) {
    for (Primitive *p : *(node->prims))
      p->drawOutline(c);
  } else {
    drawOutline(node->l, c);
    drawOutline(node->r, c);
  }
}

BVHNode *BVHAccel::construct_bvh(const std::vector<Primitive*>& prims, size_t max_leaf_size) {
  
  // TODO Part 2, task 1:
  // Construct a BVH from the given vector of primitives and maximum leaf
  // size configuration. The starter code build a BVH aggregate with a
  // single leaf node (which is also the root) that encloses all the
  // primitives.


  BBox centroid_box, bbox;
  //cout<<"!!! "<< max_leaf_size<<endl;

  for (Primitive *p : prims) {
    BBox bb = p->get_bbox();
    bbox.expand(bb);
    Vector3D c = bb.centroid();
    centroid_box.expand(c);
  }

  // You'll want to adjust this code.
  // Right now we just return a single node containing all primitives.
  BVHNode *node = new BVHNode(bbox);
  node->prims = new vector<Primitive *>(prims);
  
  if(prims.size()<=max_leaf_size)
  {
    //node->isLeaf()=true;
    node->l=NULL;
    node->r=NULL;
  }
  else
  {
    //*
    int axis = 0;
    if(bbox.extent[0]>bbox.extent[1]&&bbox.extent[0]>bbox.extent[2])
    {
      axis=0;
    }
    else if (bbox.extent[1]>bbox.extent[0]&&bbox.extent[1]>bbox.extent[2])
    {
      axis=1;
    }
    else
    {
      axis=2;
    }

    double s = (centroid_box.max[axis]+centroid_box.min[axis])/2;
    std::vector<Primitive *> l_prims=std::vector<Primitive*> ();;
    std::vector<Primitive *> r_prims=std::vector<Primitive*> ();;

    for(Primitive *p:prims)
    {
      Vector3D cp = p->get_bbox().centroid();
      if(cp[axis]>s)
      {
        r_prims.push_back(p);
      }
      else
      {
        l_prims.push_back(p);
      }
    }
    if(r_prims.size()>0)
    {
      node->r=construct_bvh(r_prims,max_leaf_size);
    }
    if(r_prims.size()==0)
      {node->r=NULL;}

    if(l_prims.size()>0)
    {
      node->l=construct_bvh(l_prims,max_leaf_size);
    }//*/
    if(l_prims.size()==0)
      {node->l=NULL;}
  }
  return node;
  

}


bool BVHAccel::intersect(const Ray& ray, BVHNode *node) const {

  // TODO Part 2, task 3:
  // Implement BVH intersection.
  // Currently, we just naively loop over every primitive.
  //cout<<"&&&&&&&&&&&&&&&&&&??"<<endl;
  if(node==NULL){return false;}
  if(node->prims->size()==0){return false;}

  double t0=ray.min_t;
  double t1=ray.max_t;
  //cout<<"!!!$$$"<<endl;
  //if(node->bb==NULL){cout<<"66666666666"<<endl;}
  if(node->bb.intersect(ray,t0,t1))
  {
    //cout<<"&&&&&&&&&&&&&&&&&&??"<<endl;
    if(node->isLeaf())
    {
      if(node->prims==NULL){return false;}
      for (Primitive *p : *(node->prims)) {
        total_isects++;
        if (p->intersect(ray)) 
          return true;
      }
    }
    return intersect(ray,node->l)||intersect(ray,node->r);
  }
  //cout<<"#######$$$"<<endl;
  return false;

}

bool BVHAccel::intersect(const Ray& ray, Intersection* i, BVHNode *node) const {

  // TODO Part 2, task 3:
  // Implement BVH intersection.
  // Currently, we just naively loop over every primitive.

  //if(node==NULL){return false;}

  //bool hit = false;
  if(node==NULL){return false;}
  if(node->prims->size()==0){return false;}
  double t0=ray.min_t;
  double t1=ray.max_t;

  if(node->bb.intersect(ray,t0,t1))
  {
    if(node->isLeaf())
    {
      bool hit = false;
      for (Primitive *p : *(node->prims)) {
        total_isects++;
        if (p->intersect(ray, i)) {
          //return true;
          hit = true;}
      }
      //ray.min_t=0.0;
      //ray.max_t=INF_D;
      return hit;
    }
    bool hit1=intersect(ray,i,node->l);
    bool hit2=intersect(ray,i,node->r);

    return hit1||hit2;//intersect(ray,i,node->l)||intersect(ray,i,node->r);
  }
  return false;

}

}  // namespace StaticScene
}  // namespace CGL
