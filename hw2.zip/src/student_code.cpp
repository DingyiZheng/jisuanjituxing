/*
 * Student solution for UC Berkeley Project 2
 *
 * Implemented by ____ on ____.
 *
 */

#include "student_code.h"
#include "mutablePriorityQueue.h"
 #include <math.h> 

namespace CGL {

    void BezierPatch::preprocess() {
        // TODO Part 1.
        // TODO If you use the matrix form for Bezier patch evaluation, you will need to
        // TODO compute your matrices based on the 16 control points here. 
        // TODO You will also need to define your matrices
        // TODO as member variables in the "BezierPatch" class.
        // TODO If you use De Casteljau's recursive algorithm, you will not need to do anything here.
       // Vector3D a = (1,2,3);
       // Vector3D b = (2,5,1);

       // cout<<a[2]<<endl;
       // cout<<pow(2,3)<<endl;

    }


     int factorial(int n){
        int fac = 1;
        for(int i = 1;i<= n;i++){
            fac = fac*i;
        }
        return fac;
    }

    Vector3D BezierPatch::evaluate(double u, double v) const {
        // TODO Part 1.
        // TODO Returns the 3D point whose parametric coordinates are (u, v) on the Bezier patch.
        // // TODO Note that both u and v are within [0, 1].
        Vector3D b = Vector3D(0,0,0);
        for(int i=0;i<4;i++){
            float Biu = factorial(3)*pow(u,i)*pow(1-u,3-i)/(factorial(i)*factorial(3-i));
            for(int j=0;j<4;j++){
                float Bjv = factorial(3)*pow(v,j)*pow(1-v,3-j)/(factorial(j)*factorial(3-j));
                b = b + controlPoints[i][j]*Biu*Bjv;
                

            }
        }

        //return Vector3D();
        //cout<<b<<endl;
        return b;
    }


    void BezierPatch::add2mesh(Polymesh* mesh) const {
        // TODO Part 1.
        // TODO Tessellate the given Bezier patch into triangles uniformly on a 8x8 grid(8x8x2=128 triangles) in parameter space.
        // TODO You will call your own evaluate function here to compute vertex positions of the tessellated triangles.
        // TODO The "addTriangle" function inherited from the "BezierPatchLoader" class may help you add triangles to the output mesh.
        for(int i=0;i<8;i++){
            double u = 0.125*i;
            for (int j = 0; j < 8; j++)
            {
                double v = 0.125*j;
                Vector3D parameters1 = evaluate(u,v);
                Vector3D parameters2 = evaluate(u+0.125,v);
                Vector3D parameters3 = evaluate(u,v+0.125);
                Vector3D parameters4 = evaluate(u+0.125,v+0.125);
                addTriangle( mesh, parameters1,parameters3,parameters2); 
                addTriangle( mesh, parameters3,parameters4,parameters2); 
            }
        }
        

    }

    Vector3D Vertex::normal(void) const
    // TODO Part 2.
    // TODO Returns an approximate unit normal at this vertex, computed by
    // TODO taking the area-weighted average of the normals of neighboring
    // TODO triangles, then normalizing.
    {
        // TODO Compute and return the area-weighted unit normal.

        HalfedgeCIter h = halfedge();
        HalfedgeCIter h_orig = h;
        Vector3D sum(0.,0.,0.);
        Vector3D fnormal;
        FaceCIter face1 = h->face();

       //  do
       //  {
       // // do something interesting with h

       //    face1 = h->face();
       //    fnormal = face1->normal();
       //    sum = sum + fnormal;

       //    h = h->twin()->next();
       //  }while( h != h_orig );

       do
        {
       // do something interesting with h

           Vector3D pi = h->vertex()->position;
         Vector3D pj = h->next()->vertex()->position;
         Vector3D pk = h->next()->next()->vertex()->position;
         Vector3D facenormal = cross(pj-pi,pk-pj);
         sum += facenormal.unit();
         h = h->twin()->next();
        }while( h != h_orig );

        float abs_sum = sqrt(sum[0]*sum[0] + sum[1]*sum[1] + sum[2]*sum[2]);
        if(abs_sum==0.0){
            return sum;
        }else{
        sum[0] = sum[0]/abs_sum;
         sum[1] = sum[1]/abs_sum;
          sum[2] = sum[2]/abs_sum;
          return sum;
        }



       // return sum;
    }

    EdgeIter HalfedgeMesh::flipEdge(EdgeIter e0) {
        // TODO Part 3.
        // // // TODO This method should flip the given edge and return an iterator to the flipped edge.
       // HalfedgeCIter ca = e0->halfedge();//ac
        FaceIter f1 = e0->halfedge()->face();
        FaceIter f2 = e0->halfedge()->twin()->face();
        if(f1->isBoundary() || f2->isBoundary()){
            return e0;

        }else{
        HalfedgeIter ac = e0->halfedge();
        HalfedgeIter cb = e0->halfedge()->next();
        HalfedgeIter ba = e0->halfedge()->next()->next();
        HalfedgeIter ca = e0->halfedge()->twin();
        HalfedgeIter ad = e0->halfedge()->twin()->next();
        HalfedgeIter dc = e0->halfedge()->twin()->next()->next();
        HalfedgeIter bc = cb->twin();
        HalfedgeIter ab = ba->twin();
        HalfedgeIter da = ad->twin();
        HalfedgeIter cd = dc->twin();
        EdgeIter edge_ac = ac->edge();
        EdgeIter edge_cb = cb->edge();
        EdgeIter edge_ba = ba->edge();
        EdgeIter edge_ad = ad->edge();
        EdgeIter edge_dc = dc->edge();
        VertexIter a = ac->vertex();
        VertexIter b = ba->vertex();
        VertexIter c = ca->vertex();
        VertexIter d = dc->vertex();

        ac -> setNeighbors(dc, ca, b, edge_ac,f1 );
        ca -> setNeighbors(ba, ac, d, edge_ac,f2 );
        cb -> setNeighbors(ac, bc, c, edge_cb,f1 );
        ba -> setNeighbors(ad, ab, b, edge_ba,f2 );
        ad -> setNeighbors(ca, da, a, edge_ad,f2 );
        dc -> setNeighbors(cb, cd, d, edge_dc,f1 );

        f1->halfedge() = ac;
        f2->halfedge() = ca;

        a->halfedge() = ad;
        b->halfedge() = ba;
        c->halfedge() = cb;
        d->halfedge() = dc;






        ///////////////////////////////////////////////////////////////////////    

           
        // HalfedgeIter ad = e0->halfedge()->next();
        // HalfedgeIter dc = e0->halfedge()->next()->next();
        // ///modify face
        // e0->halfedge() -> next() -> next() -> face() = e0->halfedge() -> twin() -> face(); 
        // //ba
        // e0->halfedge() -> twin() -> next() -> next() -> face() = e0->halfedge() -> face();

        // ///modify vertex
        // e0->halfedge() -> vertex() = e0->halfedge() -> next() -> next() -> vertex();
        // e0->halfedge() -> twin() -> vertex() = e0->halfedge() -> twin() -> next() -> next() -> vertex();

        // ///modify next
        // e0->halfedge() -> next() -> next() -> next() = e0->halfedge() -> twin() -> next(); //dc
        // e0->halfedge() -> next() -> next() = e0->halfedge();//ad
        // e0->halfedge() -> next() = e0->halfedge() -> twin() -> next() -> next();//db

        // e0->halfedge() -> twin() -> next() -> next() -> next() = ad;//ac2ad
        // e0->halfedge() -> twin() -> next() -> next() = e0->halfedge() -> twin();//ba2bd
        // e0->halfedge() -> twin() -> next() = dc;//cb2dc

        // ///modify face
        // e0 -> halfedge() -> face() -> halfedge() = e0 -> halfedge();
        // e0 -> halfedge() -> twin() -> face() -> halfedge() = e0 ->halfedge() -> twin();

        return e0;
        }
    }

    VertexIter HalfedgeMesh::splitEdge(EdgeIter e0) {
        // TODO Part 4.
        // TODO This method should split the given edge and return an iterator to the newly inserted vertex.
        // TODO The halfedge of this vertex should point along the edge that was split, rather than the new edges.

        Vector3D c_p = e0 -> halfedge() -> vertex() -> position;
        Vector3D a_p = e0 -> halfedge() -> next() -> next()-> vertex() -> position;
        Vector3D b_p = e0 -> halfedge() -> next() -> vertex() -> position;
        Vector3D d_p = e0 -> halfedge() -> twin() -> next() -> next() -> vertex() -> position;

        VertexIter v = newVertex();
        v -> position = (a_p+b_p+c_p+d_p)*0.25;
        v->isNew = true;

        FaceIter f3 = newFace();
        FaceIter f4 = newFace();
        EdgeIter edge_eb = newEdge();
        EdgeIter edge_ea = newEdge();
        EdgeIter edge_ed = newEdge();
        HalfedgeIter de = newHalfedge();
        HalfedgeIter ea = newHalfedge();
        HalfedgeIter ae = newHalfedge();
        HalfedgeIter eb = newHalfedge();
        HalfedgeIter be = newHalfedge();
        HalfedgeIter ed = newHalfedge();



        FaceIter f1 = e0->halfedge()->face();
        FaceIter f2 = e0->halfedge()->twin()->face();

        HalfedgeIter ac = e0->halfedge();
        HalfedgeIter cb = e0->halfedge()->next();
        HalfedgeIter ba = e0->halfedge()->next()->next();
        HalfedgeIter ca = e0->halfedge()->twin();
        HalfedgeIter ad = e0->halfedge()->twin()->next();
        HalfedgeIter dc = e0->halfedge()->twin()->next()->next();
        HalfedgeIter bc = cb->twin();
        HalfedgeIter ab = ba->twin();
        HalfedgeIter da = ad->twin();
        HalfedgeIter cd = dc->twin();
        EdgeIter edge_ac = ac->edge();
        EdgeIter edge_cb = cb->edge();
        EdgeIter edge_ba = ba->edge();
        EdgeIter edge_ad = ad->edge();
        EdgeIter edge_dc = dc->edge();
        VertexIter a = ac->vertex();
        VertexIter b = ba->vertex();
        VertexIter c = ca->vertex();
        VertexIter d = dc->vertex();


        //setting isnew
        edge_ea->isNew = false;
        edge_eb->isNew = true;
        edge_ed->isNew = true;
        edge_ac->isNew = false;


        ac -> setNeighbors(cb, ca, v, edge_ac,f1 );
        cb -> setNeighbors(be, bc, c, edge_cb,f1 );
        be -> setNeighbors(ac, eb, b, edge_eb,f1 );
        ca -> setNeighbors(ed, ac, c, edge_ac,f2 );
        ed -> setNeighbors(dc, de, v, edge_ed,f2 );
        dc -> setNeighbors(ca, cd, d, edge_dc,f2 );
        ae -> setNeighbors(eb, ea, a, edge_ea,f3 );
        eb -> setNeighbors(ba, be, v, edge_eb,f3 );
        ba -> setNeighbors(ae, ab, b, edge_ba,f3 );
        ea -> setNeighbors(ad, ae, v, edge_ea,f4 );
        ad -> setNeighbors(de, da, a, edge_ad,f4 );
        de -> setNeighbors(ea, ed, d, edge_ed,f4 );


        f1->halfedge() = ac;
        f2->halfedge() = ca;
        f3->halfedge() = ae;
        f4->halfedge() = ea;


        a->halfedge() = ad;
        b->halfedge() = ba;
        c->halfedge() = cb;
        d->halfedge() = dc;
        v->halfedge() = ac;

        edge_ea->halfedge() = ea;
        edge_eb->halfedge() = eb;
        edge_ed->halfedge() = ed;


//////////////////////////////////////////////////////////////////////////////////

        // //connect new edge with new halfedge
        // edge_ea -> halfedge() = he_ea;
        // edge_eb -> halfedge() = he_eb;
        // edge_ed -> halfedge() = he_ed;


        // //connect new face with new halfedge
        // face3 -> halfedge() = he_ed;
        // face4 -> halfedge() = he_eb;
        // e0 -> halfedge() -> face() -> halfedge() = e0 -> halfedge();
        // e0 -> halfedge() -> twin() -> face() -> halfedge() = e0 -> halfedge() -> twin();

        //         //assign halfedge to new vertex
        // v -> halfedge() = he_ea;
        // e0 -> halfedge() -> twin() -> vertex()->halfedge() = he_be;



        // //assign twin to new halfedge
        // he_ea -> twin() = he_ae;
        // he_ae -> twin() = he_ea;
        // he_eb -> twin() = he_be;
        // he_be -> twin() = he_eb;
        // he_ed -> twin() = he_de;
        // he_de -> twin() = he_ed;

        // //reassign vertex for halfedge
        // e0 -> halfedge() -> twin() -> vertex() = v;

        // he_ea -> vertex() = v;
        // he_ae -> vertex() = e0 -> halfedge() -> next() -> next() -> vertex();
        // he_eb -> vertex() = v;
        // he_be -> vertex() = e0 -> halfedge() -> next() -> vertex();
        // he_ed -> vertex() = v;
        // he_de -> vertex() = e0 -> halfedge() -> twin() -> next() -> next() -> vertex();

        
        // //reassign face to halfedge
        // he_ea -> face() = e0 -> halfedge() -> face();//ea.face
        // he_de -> face() = e0 -> halfedge() -> twin() -> face();
        // he_eb -> face() = face4;
        // he_ae -> face() = face4;
        // he_be -> face() = face3;
        // he_ed -> face() = face3;
        // // he_eb -> next() -> face() = face4;
        // // he_ed -> next() -> face() = face3;
        // e0 -> halfedge() -> next() -> face() = face4;
        // e0 -> halfedge() -> twin() -> next() -> next() -> face() = face3;




        // //reassign next
        // he_ae -> next() = he_eb;
        // he_ea -> next() = e0 -> halfedge() -> next() -> next();
        // he_eb -> next() = e0 -> halfedge() -> next();
        // he_be -> next() = he_ed;
        // he_ed -> next() = e0 -> halfedge() -> twin() -> next() -> next();
        // he_de -> next() = e0 -> halfedge() -> twin();

        // // //reassign face to ba db
        // // he_eb -> next() -> face() = face4;
        // // he_ed -> next() -> face() = face3;

        // e0 -> halfedge() -> next() -> next() = he_ae;//ba.next
        // e0 -> halfedge() -> twin() -> next() -> next() -> next() = he_be;//db.next
        // e0 -> halfedge() -> twin() -> next() -> next() = he_de;
        // e0 -> halfedge() -> next() = he_ea;


        return v;
    }

    void MeshResampler::upsample(HalfedgeMesh& mesh)
    // TODO Part 5.
    // This routine should increase the number of triangles in the mesh using Loop subdivision.
    {
        // Each vertex and edge of the original surface can be associated with a vertex in the new (subdivided) surface.
        // Therefore, our strategy for computing the subdivided vertex locations is to *first* compute the new positions
        // using the connectity of the original (coarse) mesh; navigating this mesh will be much easier than navigating
        // the new subdivided (fine) mesh, which has more elements to traverse.  We will then assign vertex positions in
        // the new mesh based on the values we computed for the original mesh.


        // TODO Compute new positions for all the vertices in the input mesh, using the Loop subdivision rule,
        // TODO and store them in Vertex::newPosition. At this point, we also want to mark each vertex as being
        // TODO a vertex of the original mesh.
        for(VertexIter Viter = mesh.verticesBegin();Viter != mesh.verticesEnd();Viter++){
            HalfedgeIter h0 = Viter->halfedge();
            int n=0;
            Vector3D neighbor_position_sum = (.0,.0,.0);
            // for(HalfedgeIter h1 = Viter->halfedge();h1!=h0;n++){
            //    neighbor_position_sum += h1->twin()->vertex()->position;
            //    h1 = h1->twin()->next();
               

            // }
            HalfedgeIter h1 = Viter->halfedge();
            do{
              neighbor_position_sum += h1->twin()->vertex()->position;
               h1 = h1->twin()->next();
               n++;

            }while(h1!=h0);
            //cout<<n<<endl;
            float u = .0;
            if(n==3){
                u = 3.0/16.0;
            }else{
                u = 3.0/(8.0*n);
            }
            Vector3D newposi = (1.0 - n*u) * (Viter->position )+ u * neighbor_position_sum;
            Viter->newPosition = newposi;
            Viter->isNew = false;
           
           
        }



        // TODO Next, compute the updated vertex positions associated with edges, and store it in Edge::newPosition.
        

        Vector3D A = (.0,.0,.0);
        Vector3D B = (.0,.0,.0);
        Vector3D C = (.0,.0,.0);
        Vector3D D = (.0,.0,.0);
        for(EdgeIter Eiter = mesh.edgesBegin();Eiter!=mesh.edgesEnd();Eiter++){
            A = Eiter->halfedge()->vertex()->position;
            B = Eiter->halfedge()->twin()->vertex()->position;
            C = Eiter->halfedge()->next()->next()->vertex()->position;
            D = Eiter->halfedge()->twin()->next()->next()->vertex()->position;
            Eiter->newPosition = (3.0/8.0)*(A+B) + (1.0/8.0)*(C+D);
            Eiter->isNew = false;
        }


        // TODO Next, we're going to split every edge in the mesh, in any order.  For future
        // TODO reference, we're also going to store some information about which subdivided
        // TODO edges come from splitting an edge in the original mesh, and which edges are new,
        // TODO by setting the flat Edge::isNew.  Note that in this loop, we only want to iterate
        // TODO over edges of the original mesh---otherwise, we'll end up splitting edges that we
        // TODO just split (and the loop will never end!)
        Size n = mesh.nEdges();
       // cout<<true*false<<endl;
        // EdgeIter Eiter2 = mesh.edgesBegin();
        // for(int i = 0;i<n;i++,Eiter2++){
        //     if(Eiter2->isNew != true){
        //     VertexIter Viter2 = mesh.splitEdge(Eiter2);
        //     Viter2->halfedge()->twin()->next()->twin()->next()->edge()->isNew = true;
        //     }

        // }
        int count = 0;
        int count2 = 0;
        for(EdgeIter Eiter2 = mesh.edgesBegin();Eiter2!=mesh.edgesEnd();Eiter2++){
           // if(Eiter2->isNew != true){
            count++;
            if(!(Eiter2->isNew)&&!(Eiter2->halfedge()->vertex()->isNew)&&!(Eiter2->halfedge()->twin()->vertex()->isNew)){
            Vector3D position = Eiter2->newPosition;
            count2 = 0;
            VertexIter Viter2 = mesh.splitEdge(Eiter2);
          // // Viter2->halfedge()->twin()->next()->twin()->next()->edge()->isNew = false;
            Viter2->position = position;//
            }

        }
        cout<<"count"<<count<<endl;
        cout<<"count2"<<count2<<endl;

        //try do while



        // TODO Now flip any new edge that connects an old and new vertex.
        for(EdgeIter Eiter3 = mesh.edgesBegin();Eiter3!=mesh.edgesEnd();Eiter3++){
            if(Eiter3->isNew == true){
               // cout<<"222"<<endl;
                if(Eiter3->halfedge()->vertex()->isNew != Eiter3->halfedge()->twin()->vertex()->isNew){
                mesh.flipEdge(Eiter3);
                //cout<<"111"<<endl;
                }

            }
        }


        // TODO Finally, copy the new vertex positions into final Vertex::position.
        for(VertexIter Viter3 = mesh.verticesBegin();Viter3 != mesh.verticesEnd();Viter3++){
           // if(Viter3->isNew==true){
           //  Viter3->position = Viter3->halfedge()->edge()->newPosition;
           //  cout<<Viter3->position<<"1"<<endl;
           // }else{
           //  Viter3->position = Viter3->newPosition;
           //  cout<<Viter3->position<<"2"<<endl;
           // }

            if(Viter3->isNew==true){
           // Viter3->position = Viter3->halfedge()->edge()->newPosition;
           // cout<<Viter3->position<<"1"<<endl;
           }else{
            Viter3->position = Viter3->newPosition;
          //  cout<<Viter3->position<<"2"<<endl;
           }
        }
 


       


 //     At each iteration we walk to the "next" halfedge, until we return
 // * to the original starting point.  A slightly more interesting
 // * example is iterating around a vertex:
 // *
 // *    HalfEdgeIter h = myVertex->halfedge();
 // *    do
 // *    {
 // *       // do something interesting with h
 // *       h = h->twin()->next();
 // *    }
 // *    while( h != myVertex->halfedge() );

    }

    // TODO Part 6.
    // TODO There's also some code you'll need to complete in "Shader/frag" file.

}
