var searchData=
[
  ['vertex',['vertex',['../class_c_m_u462_1_1_halfedge.html#a21679db428e2cf0b156cc15053fa5ca7',1,'CGL::Halfedge::vertex(void)'],['../class_c_m_u462_1_1_halfedge.html#aecd28c09628c5c4ac31811aac5b23539',1,'CGL::Halfedge::vertex(void) const ']]]
];
