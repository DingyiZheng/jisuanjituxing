var searchData=
[
  ['isboundary',['isBoundary',['../class_c_m_u462_1_1_halfedge.html#ac63ad32c5a4524733545d8b17e664ad1',1,'CGL::Halfedge::isBoundary()'],['../class_c_m_u462_1_1_face.html#a879d84e7cf55ca86ee3c498116d04340',1,'CGL::Face::isBoundary()'],['../class_c_m_u462_1_1_vertex.html#ac3962559525eb43438e34b4344454e13',1,'CGL::Vertex::isBoundary()']]]
];
