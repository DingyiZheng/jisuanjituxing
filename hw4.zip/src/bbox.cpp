#include "bbox.h"

#include "GL/glew.h"

#include <algorithm>
#include <iostream>

namespace CGL {

bool BBox::intersect(const Ray& r, double& t0, double& t1) const {

  // TODO Part 2, task 2:
  // Implement ray - bounding box intersection test
  // If the ray intersected the bounding box within the range given by
  // t0, t1, update t0 and t1 with the new intersection times.

 // return false;
  double tmin_x;
  double tmin_y;
  double tmin_z;
  double tmax_x;
  double tmax_y;
  double tmax_z;
  tmin_x = (min[0]-r.o[0])/r.d[0];
  tmax_x = (max[0]-r.o[0])/r.d[0];
  tmin_y = (min[1]-r.o[1])/r.d[1];
  tmax_y = (max[1]-r.o[1])/r.d[1];
  tmin_z = (min[2]-r.o[2])/r.d[2];
  tmax_z = (max[2]-r.o[2])/r.d[2];


    if(tmin_x>tmax_x){
      std::swap(tmin_x,tmax_x);
    }
    if(tmin_y>tmax_y){
      std::swap(tmin_y,tmax_y);
    }
    if(tmin_z>tmax_z){
      std::swap(tmin_z,tmax_z);
    }
  
  double tmin = std::max(tmin_x,std::max(tmin_y,tmin_z));
  double tmax = std::min(tmax_x,std::min(tmax_y,tmax_z));
  //if(tmin<=tmax&&((tmin>=t0&&tmin<=t1)||(tmax<=t1&&tmax>=t0))){
  //if(tmin<=tmax && tmin<=t1 && tmax>=t0){
  if(tmin<=tmax && tmin<=t1 && tmax>=t0){
   // std::cout<<tmin<<std::endl;
    t0 = tmin;
    t1 = tmax;
/*    t0 = std::max(t0,tmin);
    t1 = std::min(t1,tmax);*/

    return true;
  }
  
  return false;
  


 
}

void BBox::draw(Color c) const {

  glColor4f(c.r, c.g, c.b, c.a);

	// top
	glBegin(GL_LINE_STRIP);
	glVertex3d(max.x, max.y, max.z);
  glVertex3d(max.x, max.y, min.z);
  glVertex3d(min.x, max.y, min.z);
  glVertex3d(min.x, max.y, max.z);
  glVertex3d(max.x, max.y, max.z);
	glEnd();

	// bottom
	glBegin(GL_LINE_STRIP);
  glVertex3d(min.x, min.y, min.z);
  glVertex3d(min.x, min.y, max.z);
  glVertex3d(max.x, min.y, max.z);
  glVertex3d(max.x, min.y, min.z);
  glVertex3d(min.x, min.y, min.z);
	glEnd();

	// side
	glBegin(GL_LINES);
	glVertex3d(max.x, max.y, max.z);
  glVertex3d(max.x, min.y, max.z);
	glVertex3d(max.x, max.y, min.z);
  glVertex3d(max.x, min.y, min.z);
	glVertex3d(min.x, max.y, min.z);
  glVertex3d(min.x, min.y, min.z);
	glVertex3d(min.x, max.y, max.z);
  glVertex3d(min.x, min.y, max.z);
	glEnd();

}

std::ostream& operator<<(std::ostream& os, const BBox& b) {
  return os << "BBOX(" << b.min << ", " << b.max << ")";
}

} // namespace CGL
