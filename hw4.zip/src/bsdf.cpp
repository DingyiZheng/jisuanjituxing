#include "bsdf.h"

#include <iostream>
#include <algorithm>
#include <utility>

using std::min;
using std::max;
using std::swap;

namespace CGL {

void make_coord_space(Matrix3x3& o2w, const Vector3D& n) {

    Vector3D z = Vector3D(n.x, n.y, n.z);
    Vector3D h = z;
    if (fabs(h.x) <= fabs(h.y) && fabs(h.x) <= fabs(h.z)) h.x = 1.0;
    else if (fabs(h.y) <= fabs(h.x) && fabs(h.y) <= fabs(h.z)) h.y = 1.0;
    else h.z = 1.0;

    z.normalize();
    Vector3D y = cross(h, z);
    y.normalize();
    Vector3D x = cross(z, y);
    x.normalize();

    o2w[0] = x;
    o2w[1] = y;
    o2w[2] = z;
}

// Diffuse BSDF //

Spectrum DiffuseBSDF::f(const Vector3D& wo, const Vector3D& wi) {
  return albedo * (1.0 / PI);
}

Spectrum DiffuseBSDF::sample_f(const Vector3D& wo, Vector3D* wi, float* pdf) {
  *wi = sampler.get_sample(pdf);
  return albedo * (1.0 / PI);
}

// Mirror BSDF //

Spectrum MirrorBSDF::f(const Vector3D& wo, const Vector3D& wi) {
  if(wi==2*wo.z*Vector3D(0,0,1.0)-wo)
    {
      //std::cout<<"!!"<<std::endl;
      return reflectance;
    }
  return 0.0*reflectance;
  //return Spectrum();
}

Spectrum MirrorBSDF::sample_f(const Vector3D& wo, Vector3D* wi, float* pdf) {

  // TODO Part 5:
  // Implement MirrorBSDF
  *pdf=1.0;
  *wi=2*wo.z*Vector3D(0,0,1.0)-wo;
  return 1.0*reflectance;
  //return Spectrum();
}

// Glossy BSDF //

/*
Spectrum GlossyBSDF::f(const Vector3D& wo, const Vector3D& wi) {
  return Spectrum();
}

Spectrum GlossyBSDF::sample_f(const Vector3D& wo, Vector3D* wi, float* pdf) {
  *pdf = 1.0f;
  return reflect(wo, wi, reflectance);
}
*/

// Refraction BSDF //

Spectrum RefractionBSDF::f(const Vector3D& wo, const Vector3D& wi) {

  Vector3D wi2=wi;
  if(refract(wo,&wi2,ior))
  {
    if(wi2==wi)
      return transmittance*0;
  }

  return transmittance*0.0;
}

Spectrum RefractionBSDF::sample_f(const Vector3D& wo, Vector3D* wi, float* pdf) {

  // TODO Part 5:
  // Implement RefractionBSDF

  *pdf=0.10;
  if(refract(wo,wi,ior))
    {return transmittance*0;}
  return transmittance*0.0;
}

// Glass BSDF //

Spectrum GlassBSDF::f(const Vector3D& wo, const Vector3D& wi) {


  Vector3D w_in=wi;
  if(refract(wo,&w_in,ior))
  {
    if(w_in==wi)
    {
      float r0=(ior-1)*(ior-1)/(ior+1)/(ior+1);
      double abswo2=wo[2];
      if(wo[2]<0){abswo2=-abswo2;}
      float r=r0+(1-r0)*pow(1.0-abswo2,5);
      return transmittance*(1-r)/abswo2;
    }
    else
    {
      float r0=(ior-1)*(ior-1)/(ior+1)/(ior+1);
      double abswo2=wo[2];
      if(wo[2]<0){abswo2=-abswo2;}
      float r=r0+(1-r0)*pow(1.0-abswo2,5);
      return reflectance*(r)/abswo2;
      return transmittance*0.0;
    }
  }
  else
  {
    return reflectance/wo[2];//reflectance+
  }
  //return Spectrum();
}

Spectrum GlassBSDF::sample_f(const Vector3D& wo, Vector3D* wi, float* pdf) {

  // TODO Part 5:
  // Compute Fresnel coefficient and either reflect or refract based on it.
  
  if(refract(wo,wi,ior))
  {
    float r0=(ior-1)*(ior-1)/(ior+1)/(ior+1);
    double abswo2=wo[2];
    if(wo[2]<0){abswo2=-abswo2;}
    double r=r0+(1-r0)*pow(1.0-abswo2,5);

    if(coin_flip(r))
    {
      *pdf=r;
      *wi=2*wo.z*Vector3D(0,0,1.0)-wo;
      return reflectance*(r);
    }
    else
    {
      *pdf=(1-r);
      return transmittance*(1-r);
    }
  }

  *pdf=1.0;
  return reflectance;
  
  //return Spectrum();
}

void BSDF::reflect(const Vector3D& wo, Vector3D* wi) {

  // TODO Part 5:
  // Implement reflection of wo about normal (0,0,1) and store result in wi.
  *wi=2*wo.z*Vector3D(0,0,1.0)-wo;

}

bool BSDF::refract(const Vector3D& wo, Vector3D* wi, float ior) {

  // TODO Part 5:
  // Use Snell's Law to refract wo surface and store result ray in wi.
  // Return false if refraction does not occur due to total internal reflection
  // and true otherwise. When dot(wo,n) is positive, then wo corresponds to a
  // ray entering the surface through vacuum.
  
  if(wo[2]<0)
  {
    float o=sqrt(1-wo[2]*wo[2]);
    float i=o*ior;
    if(i<1)
    {
      *wi=-wo;
      wi->z=sqrt(1-i*i);
      float f=sqrt(i*i/(wo[0]*wo[0]+wo[1]*wo[1]));
      wi->x=wi->x*f;
      wi->y=wi->y*f;
      wi->normalize();
      return true;
    }
    *wi=2*wo.z*Vector3D(0,0,1.0)-wo;
    return false;
  }
  
  else
  {
    float o=sqrt(1-wo[2]*wo[2]);
    float i=o/ior;
      *wi=-wo;
      wi->z=-sqrt(1-i*i);
      float f=sqrt(i*i/(wo[0]*wo[0]+wo[1]*wo[1]));
      wi->x=wi->x*f;
      wi->y=wi->y*f;
      wi->normalize();
      return true;
    
  }

}

// Emission BSDF //

Spectrum EmissionBSDF::f(const Vector3D& wo, const Vector3D& wi) {
  return Spectrum();
}

Spectrum EmissionBSDF::sample_f(const Vector3D& wo, Vector3D* wi, float* pdf) {
  *pdf = 1.0 / PI;
  *wi  = sampler.get_sample(pdf);
  return Spectrum();
}

} // namespace CGL
