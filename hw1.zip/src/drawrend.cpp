#include "drawrend.h"
#include "svg.h"
#include "transforms.h"
#include "CGL/misc.h"
#include <iostream>
#include <sstream>
#include "CGL/lodepng.h"
#include "texture.h"
#include <ctime>

using namespace std;

namespace CGL {

struct SVG;


DrawRend::~DrawRend( void ) {}

/**
* Initialize the renderer.
* Set default parameters and initialize the viewing transforms for each tab.
*/
void DrawRend::init() {
  sample_rate = 1;
  left_clicked = false;
  show_zoom = 0;

  svg_to_ndc.resize(svgs.size());
  for (int i = 0; i < svgs.size(); ++i) {
    current_svg = i;
    view_init();
  }
  current_svg = 0;
  psm = P_NEAREST;
  lsm = L_ZERO;

}

/**
* Draw content.
* Simply reposts the framebuffer and the zoom window, if applicable.
*/
void DrawRend::render() {
  draw_pixels();
  if (show_zoom)
    draw_zoom();
}

/**
 * Respond to buffer resize.
 * Resizes the buffers and resets the 
 * normalized device coords -> screen coords transform.
 * \param w The new width of the context
 * \param h The new height of the context
 */
void DrawRend::resize( size_t w, size_t h ) {
  width = w; height = h;

 framebuffer.resize(4 * w * h);
 supersample.resize(4 * w * h*sample_rate);

  //framebuffer.resize(4 * w * h*sample_rate);
 // supersample.resize(4 * w * h*sample_rate);

  float scale = min(width, height);
  ndc_to_screen(0,0) = scale; ndc_to_screen(0,2) = (width  - scale) / 2;
  ndc_to_screen(1,1) = scale; ndc_to_screen(1,2) = (height - scale) / 2;

  redraw();
}

/**
 * Return a brief description of the renderer.
 * Displays current buffer resolution, sampling method, sampling rate.
 */
static const string level_strings[] = { "level zero", "nearest level", "bilinear level interpolation"};
static const string pixel_strings[] = { "nearest pixel", "bilinear pixel interpolation"};
std::string DrawRend::info() { 
  stringstream ss;
  stringstream sample_method;
  sample_method <<  level_strings[lsm] << ", " << pixel_strings[psm];
  ss << "Resolution " << width << " x " << height << ". ";
  ss << "Using " << sample_method.str() << " sampling. ";
  ss << "Supersample rate " << sample_rate << " per pixel. ";
  return ss.str(); 
}

/**
 * Respond to cursor events.
 * The viewer itself does not really care about the cursor but it will take
 * the GLFW cursor events and forward the ones that matter to  the renderer.
 * The arguments are defined in screen space coordinates ( (0,0) at top
 * left corner of the window and (w,h) at the bottom right corner.
 * \param x the x coordinate of the cursor
 * \param y the y coordinate of the cursor
 */
void DrawRend::cursor_event( float x, float y ) { 
  // translate when left mouse button is held down
  if (left_clicked) {
    float dx = (x - cursor_x) / width  * svgs[current_svg]->width;
    float dy = (y - cursor_y) / height * svgs[current_svg]->height;
    move_view(dx,dy,1);
    redraw();
  }
  
  // register new cursor location
  cursor_x = x;
  cursor_y = y;
}

/**
 * Respond to zoom event.
 * Like cursor events, the viewer itself does not care about the mouse wheel
 * either, but it will take the GLFW wheel events and forward them directly
 * to the renderer.
 * \param offset_x Scroll offset in x direction
 * \param offset_y Scroll offset in y direction
 */
void DrawRend::scroll_event( float offset_x, float offset_y ) {
  if (offset_x || offset_y) {
    float scale = 1 + 0.05 * (offset_x + offset_y);
    scale = std::min(1.5f,std::max(0.5f,scale));
    move_view(0,0,scale);
    redraw();
  }
}

/**
 * Respond to mouse click event.
 * The viewer will always forward mouse click events to the renderer.
 * \param key The key that spawned the event. The mapping between the
 *        key values and the mouse buttons are given by the macros defined
 *        at the top of this file.
 * \param event The type of event. Possible values are 0, 1 and 2, which
 *        corresponds to the events defined in macros.
 * \param mods if any modifier keys are held down at the time of the event
 *        modifiers are defined in macros.
 */
void DrawRend::mouse_event( int key, int event, unsigned char mods ) {
  if (key == MOUSE_LEFT) {
    if (event == EVENT_PRESS)
      left_clicked = true;
    if (event == EVENT_RELEASE)
      left_clicked = false;
  }
}

/**
 * Respond to keyboard event.
 * The viewer will always forward mouse key events to the renderer.
 * \param key The key that spawned the event. ASCII numbers are used for
 *        letter characters. Non-letter keys are selectively supported
 *        and are defined in macros.
 * \param event The type of event. Possible values are 0, 1 and 2, which
 *        corresponds to the events defined in macros.
 * \param mods if any modifier keys are held down at the time of the event
 *        modifiers are defined in macros.
 */
void DrawRend::keyboard_event( int key, int event, unsigned char mods ) {
  if (event != EVENT_PRESS)
    return;

  // tab through the loaded files
  if (key >= '1' && key <= '9' && key-'1' < svgs.size()) {
    current_svg = key - '1';
    redraw();
    return;
  } 

  switch( key ) {

    // reset view transformation
    case ' ':
      view_init();
      redraw();
      break;

    // set the sampling rate to 1, 4, 9, or 16
    case '=':
      if (sample_rate < 16) {
        sample_rate = (int)(sqrt(sample_rate)+1)*(sqrt(sample_rate)+1);
         supersample.resize(4 * width * height *sample_rate);
        //supersample.resize(width,height,sample_rate);
        // Part 3: might need to add something here
        redraw();
      }
      break;
    case '-':
      if (sample_rate > 1) {
        sample_rate = (int)(sqrt(sample_rate)-1)*(sqrt(sample_rate)-1);
         supersample.resize(4 * width * height*sample_rate);
        //supersample.resize(width,height,sample_rate);
        // Part 3: might need to add something here
        redraw();
      }
      break;

    // save the current buffer to disk 
    case 'S':
      write_screenshot();
      break;

    // toggle pixel sampling scheme
    case 'P':
      psm = (PixelSampleMethod)((psm+1)%2);
      redraw();
      break;
    // toggle level sampling scheme
    case 'L':
      lsm = (LevelSampleMethod)((lsm+1)%3);
      redraw();
      break;

    // toggle zoom
    case 'Z':
      show_zoom = (show_zoom+1)%2;
      break;

    default:
      return;
  }
}

/**
 * Writes the contents of the pixel buffer to disk as a .png file.
 * The image filename contains the month, date, hour, minute, and second
 * to make sure it is unique and identifiable.
 */
void DrawRend::write_screenshot() {
    redraw();
    if (show_zoom) draw_zoom();

   vector<unsigned char> windowPixels( 4*width*height );
     //vector<unsigned char> windowPixels( 4*width*height*sample_rate);
    glReadPixels(0, 0, 
                width,
                height,
                GL_RGBA,
                GL_UNSIGNED_BYTE,
                &windowPixels[0] );

    vector<unsigned char> flippedPixels( 4*width*height );
    //vector<unsigned char> flippedPixels( 4*width*height*sample_rate);
    for (int row = 0; row < height; ++row)
      memcpy(&flippedPixels[row * width * 4], &windowPixels[(height - row - 1) * width * 4], 4*width);

    time_t t = time(nullptr);
    tm *lt = localtime(&t);
    stringstream ss;
    ss << "screenshot_" << lt->tm_mon+1 << "-" << lt->tm_mday << "_" 
      << lt->tm_hour << "-" << lt->tm_min << "-" << lt->tm_sec << ".png";
    string file = ss.str();
    cout << "Writing file " << file << "...";
    if (lodepng::encode(file, flippedPixels, width, height))
      cerr << "Could not be written" << endl;
    else 
      cout << "Success!" << endl;
}

/**
 * Draws the current SVG tab to the screen. Also draws a 
 * border around the SVG canvas. Resolves the supersample buffers
 * into the framebuffer before posting the framebuffer pixels to the screen.
 */
void DrawRend::redraw() {
  //view_init();

  supersample.resize(4 * width * height*sample_rate);
  memset(&supersample[0], 255, 4 * width * height*sample_rate);
  memset(&framebuffer[0], 255, 4 * width * height);

  SVG &svg = *svgs[current_svg];
  svg.draw(this, ndc_to_screen*svg_to_ndc[current_svg]);

  // draw canvas outline
  Vector2D a = ndc_to_screen*svg_to_ndc[current_svg]*(Vector2D(    0    ,     0    )); a.x--; a.y++;
  Vector2D b = ndc_to_screen*svg_to_ndc[current_svg]*(Vector2D(svg.width,     0    )); b.x++; b.y++;
  Vector2D c = ndc_to_screen*svg_to_ndc[current_svg]*(Vector2D(    0    ,svg.height)); c.x--; c.y--;
  Vector2D d = ndc_to_screen*svg_to_ndc[current_svg]*(Vector2D(svg.width,svg.height)); d.x++; d.y--;

  rasterize_line(a.x, a.y, b.x, b.y, Color::Black);
  rasterize_line(a.x, a.y, c.x, c.y, Color::Black);
  rasterize_line(d.x, d.y, b.x, b.y, Color::Black);
  rasterize_line(d.x, d.y, c.x, c.y, Color::Black);

  resolve();
  draw_pixels();
}

/**
 * Resolves whatever supersampling buffer you create into the
 * framebuffer pixel vector in preparation for draw_pixels();
 */
void DrawRend::resolve() {
 //framebuffer2 = framebuffer;
  // Part 3: Fill this in\


//
  memset(&framebuffer[0], 0, 4 * width * height);
   int rate = sqrt(sample_rate);
   for(int i = 0;i<width;i++){
    for(int j = 0;j<height;j++){
     unsigned char *p = &framebuffer[0] + 4 * (i + j * width);
 
      for(int m = 0;m<rate;m++){
        for(int n = 0;n<rate;n++){
        p[0] = p[0] + supersample[ j*width*sample_rate*4 + width*rate*n*4 + i*rate*4 + m*4]/sample_rate;
        p[1] = p[1] + supersample[ j*width*sample_rate*4 + width*rate*n*4 + i*rate*4 + m*4 +1]/sample_rate;
        p[2] = p[2] + supersample[ j*width*sample_rate*4 + width*rate*n*4 + i*rate*4 + m*4 +2]/sample_rate;
        p[3] = p[3] + supersample[ j*width*sample_rate*4 + width*rate*n*4 + i*rate*4 + m*4 +3]/sample_rate;
        }
      }

    }
   }


    


}

/**
 * OpenGL boilerplate to put an array of RGBA pixels on the screen.
 */
void DrawRend::draw_pixels() {
  //resolve();
  const unsigned char *pixels = &framebuffer[0];
  // copy pixels to the screen
  glPushAttrib( GL_VIEWPORT_BIT );
  glViewport(0, 0, width, height);

  glMatrixMode( GL_PROJECTION );
  glPushMatrix();
  glLoadIdentity();
  glOrtho( 0, width, 0, height, 0, 0 );

  glMatrixMode( GL_MODELVIEW );
  glPushMatrix();
  glLoadIdentity();
  glTranslatef( -1, 1, 0 );

  glRasterPos2f(0, 0);
  glPixelZoom( 1.0, -1.0 );
  glDrawPixels( width, height, GL_RGBA, GL_UNSIGNED_BYTE, pixels );
  glPixelZoom( 1.0, 1.0 );

  glPopAttrib();
  glMatrixMode( GL_PROJECTION ); glPopMatrix();
  glMatrixMode( GL_MODELVIEW  ); glPopMatrix();
}

/**
 * Reads off the pixels that should be in the zoom window, and
 * generates a pixel array with the zoomed view.
 */
void DrawRend::draw_zoom() {

  // size (in pixels) of region of interest
  size_t regionSize = 32;

  // relative size of zoom window
  size_t zoomFactor = 16;
  
  // compute zoom factor---the zoom window should never cover
  // more than 40% of the framebuffer, horizontally or vertically
  size_t bufferSize = min( width, height );
  if( regionSize*zoomFactor > bufferSize * 0.4) {
    zoomFactor = (bufferSize * 0.4 )/regionSize;
  }
  size_t zoomSize = regionSize * zoomFactor;

  // adjust the cursor coordinates so that the region of
  // interest never goes outside the bounds of the framebuffer
  size_t cX = max( regionSize/2, min( width-regionSize/2-1, (size_t) cursor_x ));
  size_t cY = max( regionSize/2, min( height-regionSize/2-1, height - (size_t) cursor_y ));

  // grab pixels from the region of interest
  vector<unsigned char> windowPixels( 3*regionSize*regionSize );
  glReadPixels( cX - regionSize/2,
                cY - regionSize/2 + 1, // meh
                regionSize,
                regionSize,
                GL_RGB,
                GL_UNSIGNED_BYTE,
                &windowPixels[0] );

  // upsample by the zoom factor, highlighting pixel boundaries
  vector<unsigned char> zoomPixels( 3*zoomSize*zoomSize );
  unsigned char* wp = &windowPixels[0];
  // outer loop over pixels in region of interest
  for( int y = 0; y < regionSize; y++ ) {
   int y0 = y*zoomFactor;
   for( int x = 0; x < regionSize; x++ ) {
      int x0 = x*zoomFactor;
      unsigned char* zp = &zoomPixels[ ( x0 + y0*zoomSize )*3 ];
      // inner loop over upsampled block
      for( int j = 0; j < zoomFactor; j++ ) {
        for( int i = 0; i < zoomFactor; i++ ) {
          for( int k = 0; k < 3; k++ ) {
            // highlight pixel boundaries
            if( i == 0 || j == 0 ) {
              const float s = .3;
              zp[k] = (int)( (1.-2.*s)*wp[k] + s*255. );
            } else {
              zp[k] = wp[k];
            }
          }
          zp += 3;
        }
        zp += 3*( zoomSize - zoomFactor );
      }
      wp += 3;
    }
  }

  // copy pixels to the screen using OpenGL
  glMatrixMode( GL_PROJECTION ); glPushMatrix(); glLoadIdentity(); glOrtho( 0, width, 0, height, 0.01, 1000. );
  glMatrixMode( GL_MODELVIEW  ); glPushMatrix(); glLoadIdentity(); glTranslated( 0., 0., -1. );
  
  glRasterPos2i( width-zoomSize, height-zoomSize );  
  glDrawPixels( zoomSize, zoomSize, GL_RGB, GL_UNSIGNED_BYTE, &zoomPixels[0] );
  glMatrixMode( GL_PROJECTION ); glPopMatrix();
  glMatrixMode( GL_MODELVIEW ); glPopMatrix();

}

/**
 * Initializes the default viewport to center and reasonably zoom the SVG
 * with a bit of margin.
 */
void DrawRend::view_init() {
  float w = svgs[current_svg]->width, h = svgs[current_svg]->height;
  set_view(w/2, h/2, 1.2 * std::max(w,h) / 2);
  //set_view(w*sqrt(sample_rate)/2, h*sqrt(sample_rate)/2, 1.2 * std::max(w*sqrt(sample_rate),h*sqrt(sample_rate)) / 2);
}

/**
 * Sets the viewing transform matrix corresponding to a view centered at 
 * (x,y) in SVG space, extending 'span' units in all four directions.
 * This transform maps to 'normalized device coordinates' (ndc), where the window
 * corresponds to the [0,1]^2 rectangle.
 */
void DrawRend::set_view(float x, float y, float span) {
  svg_to_ndc[current_svg] = Matrix3x3(1,0,-x+span,  0,1,-y+span,  0,0,2*span);
}

/**
 * Recovers the previous viewing center and span from the viewing matrix, 
 * then shifts and zooms the viewing window by setting a new view matrix.
 */
void DrawRend::move_view(float dx, float dy, float zoom) {
  // Part 4: Fill this in
      float span = svg_to_ndc[current_svg](2,2)/2;
      float x = span - svg_to_ndc[current_svg](0,2);
      float y = span - svg_to_ndc[current_svg](1,2);
      zoom = span*zoom;

      set_view(x-dx,y-dy,zoom);

    
  


}


void DrawRend::rasterize_point( float x, float y, Color color ) {
  // fill in the nearest pixel
  int rate = sqrt(sample_rate);
  /*int sx = (int) floor(x);
  int sy = (int) floor(y);
  int x_n = (x - sx)/(1/rate);
  int y_n = (y - sy)/(1/rate);
  int ssx = sx*rate + x_n;
  int ssy = sy*rate + y_n;*/
  int ssx = (int) floor(x);
  int ssy = (int) floor(y);


  // check bounds
  if ( ssx < 0 || ssx >= width*rate) return;
  if ( ssy < 0 || ssy >= height*rate ) return;

  // perform alpha blending with previous value
  unsigned char *p = &supersample[0] + 4 * (ssx + ssy * width*rate);
  //unsigned char *p = &framebuffer[0] + 4 * (ssx + ssy * width*rate);
 // unsigned char *p1 = &framebuffer[0] + 4 * (sx1 + sy1 * width);
  float Ca = p[3] / 255., Ea = color.a;
  //float Ca1 = p1[3] / 255.;
  p[0] = (uint8_t) (color.r * 255 * Ea + (1 - Ea) * p[0]);
  p[1] = (uint8_t) (color.g * 255 * Ea + (1 - Ea) * p[1]);
  p[2] = (uint8_t) (color.b * 255 * Ea + (1 - Ea) * p[2]);
  p[3] = (uint8_t) ((1 - (1 - Ea) * (1 - Ca)) * 255);

}

  // rasterize a point
void DrawRend::rasterize_point0( float x, float y, Color color ) {
  // fill in the nearest pixel
  int sx = (int) floor(x);
  int sy = (int) floor(y);

  // check bounds
  if ( sx < 0 || sx >= width ) return;
  if ( sy < 0 || sy >= height ) return;

  // perform alpha blending with previous value
  unsigned char *p = &framebuffer[0] + 4 * (sx + sy * width);
 // unsigned char *p1 = &framebuffer[0] + 4 * (sx1 + sy1 * width);
  float Ca = p[3] / 255., Ea = color.a;
  //float Ca1 = p1[3] / 255.;
  p[0] = (uint8_t) (color.r * 255 * Ea + (1 - Ea) * p[0]);
  p[1] = (uint8_t) (color.g * 255 * Ea + (1 - Ea) * p[1]);
  p[2] = (uint8_t) (color.b * 255 * Ea + (1 - Ea) * p[2]);
  p[3] = (uint8_t) ((1 - (1 - Ea) * (1 - Ca)) * 255);

}

  // rasterize a line
void DrawRend::rasterize_line( float x0, float y0,
                     float x1, float y1,
                     Color color) {

  /*const float dl = 0.125e-3;
  float l;
  int dx = x1-x0;
  int dy = y1 -y0;
  for(l = 0,0;l<1.0;l+=dl){
    rasterize_point(x0+int(floor(dx*l + 0.5)),y0+int(floor(dy*l+0.5)),color);
  }*/

  x0 = sqrt(sample_rate)*x0;
  y0 = sqrt(sample_rate)*y0;
  x1 = sqrt(sample_rate)*x1;
  y1 = sqrt(sample_rate)*y1;

       
 
       //
      int dx  = x1 - x0,
          dy  = y1 - y0,
          y   = y0,
        x = x0,
          eps = 0;

	 if(x1>=x0&&y1>=y0&&dx>=dy){
          int dx  = x1 - x0,
          dy  = y1 - y0,
          y   = y0,
        x = x0,
          eps = 0;

                                               
      for ( int x = x0; x <= x1; x++ )  {
        rasterize_point(  x,  y,  color );
        eps += dy;
        if ( (eps << 1) >= dx )  { 
	   y++;
     eps -= dx;

         }//if
      }//for


	   }//if


	 
	   	   if(x1>=x0&&y1>=y0&&dx<=dy){
                int dx  = x1 - x0,
          dy  = y1 - y0,
          y   = y0,
        x = x0,
          eps = 0;


	   	  for ( int y = y0; y <= y1; y++ )  {
	      rasterize_point(  x,  y,  color );
	     eps += dx;
	     if ( (eps << 1) >= dy )  {
	       x++;  eps -= dy;
         
	      }
	     }
	   	  }



   if(x1<=x0&&y1<=y0&&dx<=dy){

          int dx  = x0 - x1,
          dy  = y0 - y1,
          y   = y1,
          x = x1,
          eps = 0;

                                               
      for ( int x = x1; x <= x0; x++ )  {
        rasterize_point(  x,  y,  color );
        eps += dy;
        if ( (eps << 1) >= dx )  { 
     y++;
     eps -= dx;
         
  }//if
      }//for
     }//if



      if(x1<=x0&&y1<=y0&&dx>=dy){

          int dx  = x0 - x1,
          dy  = y0 - y1,
          y   = y1,
          x = x1,
          eps = 0;


        for ( int y = y1; y <= y0; y++ )  {
        rasterize_point(  x,  y,  color );
       eps += dx;
       if ( (eps << 1) >= dy )  {
         x++;  eps -= dy;
         
        }
       }
        }


if(x1<=x0&&y1>y0&&(x0-x1)>=(y1-y0)){

  int dx  = x0 - x1,
          dy  = y1 - y0,
          y   = y0,
          x = x0,
          eps = 0;

                                               
      for ( int x = x0; x >= x1; x-- )  {
        rasterize_point(  x,  y,  color );
       eps += dy;
       
        if ( (eps << 1) >= dx )  { 


     y++;
     eps -= dx;

         
  }//if
      }//for
     }//iff


     if(x1<=x0&&y1>y0&&(x0-x1)<=(y1-y0)){

  int dx  = x0 - x1,
          dy  = y1 - y0,
          y   = y0,
          x = x0,
          eps = 0;

                                               
      for ( int y = y0; y <= y1; y++ )  {
        rasterize_point(  x,  y,  color );
       eps += dx;
       
        if ( (eps << 1) >= dy )  { 
     x--;
     eps -= dy;

         
  }//if
      }//for
     }//iff
	  


if(x1>=x0&&y1<y0&&(x1-x0)>=(y0-y1)){

  int dx  = x1 - x0,
          dy  = y0 - y1,
          y   = y1,
          x = x0,
          eps = 0;

                                               
      for ( int x = x1; x >= x0; x-- )  {
        rasterize_point(  x,  y,  color );
       eps += dy;
       
        if ( (eps << 1) >= dx )  { 


     y++;
     eps -= dx;

         
  }//if
      }//for
     }//iff
	   

     if(x1>=x0&&y1<=y0&&(x1-x0)<=(y0-y1)){

  int dx  = x1 - x0,
          dy  = y0 - y1,
          y   = y1,
          x = x1,
          eps = 0;

                                               
      for ( int y = y1; y <= y0; y++ )  {
        rasterize_point(  x,  y,  color );
       eps += dx;
       
        if ( (eps << 1) >= dy )  { 
     x--;
     eps -= dy;

         
  }//if
      }//for
     }//iff

     

  // Part 1: Fill this in

}

  // rasterize a triangle
void DrawRend::rasterize_triangle( float x0, float y0,
                         float x1, float y1,
                         float x2, float y2,
                         Color color, Triangle *tri) {


  x0 = sqrt(sample_rate)*x0;
  y0 = sqrt(sample_rate)*y0;
  x1 = sqrt(sample_rate)*x1;
  y1 = sqrt(sample_rate)*y1;
  x2 = sqrt(sample_rate)*x2;
  y2 = sqrt(sample_rate)*y2;



  
  float xmin = x0,ymin = y0,xmax = x2,ymax = y2;
  if(x1<x0||x2<x0){
    xmin = x1;
    if( x2<x1){
      xmin = x2;
    }//if
  }//if

    if(y1<y0||y2<y0){
    ymin = y1;
    if( y2<y1){
      ymin = y2;
    }//if
  }//if

  if(x0>x2||x1>x2){
    xmax = x0;
    if( x0<x1){
      xmax = x1;
    }//if
  }//if

    if(y0>y2||y1>y2){
    ymax = y0;
    if( y1>y0){
      ymax = y1;
    }//if
  }//if

  float x10 = x1-x0,x20 = x2-x0,y10 = y1-y0,y20 = y2-y0;

  float u,v;
  int rate = sqrt(sample_rate);
  float d = 1/rate;
  for(int x = xmin;x<=xmax;x++){
    for(int y = ymin;y<=ymax;y++){

        //  u = ((y-y0)*x20-(x-x0)*y20)/(x20*y10-x10*y20);
         // v = ((y-y0)*x10-(x-x0)*y10)/(x10*y20-x20*y10);
     // if(u>=0&&v>=0&&(u+v)<=1){
      for(float i = 0;i< rate;i++){
        for(float j = 0;j< rate;j++){
          float xx = x+i*d;
          float yy = y+j*d;
          u = ((yy-y0)*x20-(xx-x0)*y20)/(x20*y10-x10*y20);
          v = ((yy-y0)*x10-(xx-x0)*y10)/(x10*y20-x20*y10);
          if(u>=0&&v>=0&&(u+v)<=1){
            if(tri ){
              float alpha = (-(xx-x1)*(y2-y1)+(yy-y1)*(x2-x1))/(-(x0-x1)*(y2-y1)+(y0-y1)*(x2-x1));
              float beta = (-(xx-x2)*(y0-y2)+(yy-y2)*(x0-x2))/(-(x1-x2)*(y0-y2)+(y1-y2)*(x0-x2));

              float dx1 = (-(xx+1-x1)*(y2-y1)+(yy-y1)*(x2-x1))/(-(x0-x1)*(y2-y1)+(y0-y1)*(x2-x1));
              float dx2 = (-(xx+1-x2)*(y0-y2)+(yy-y2)*(x0-x2))/(-(x1-x2)*(y0-y2)+(y1-y2)*(x0-x2));

              float dy1 = (-(xx-x1)*(y2-y1)+(yy+1-y1)*(x2-x1))/(-(x0-x1)*(y2-y1)+(y0-y1)*(x2-x1));
              float dy2 = (-(xx-x2)*(y0-y2)+(yy+1-y2)*(x0-x2))/(-(x1-x2)*(y0-y2)+(y1-y2)*(x0-x2));




              Vector2D xy = Vector2D(alpha,beta);
              Vector2D dx = Vector2D(dx1,dx2);
              Vector2D dy = Vector2D(dy1,dy2);

              SampleParams sp;
              sp.psm = psm;
              sp.lsm = lsm;
              //color = tri->color(xy,Vector2D(),Vector2D(),sp);
              color = tri->color(xy,dx,dy,sp);

             }
             rasterize_point(  xx,  yy, color );
 
           }

        }
      }
  


    }

  }






  // Part 2: Fill in this function with basic triangle rasterization code
  // Part 3: Add supersampling to antialias your triangles
  // Part 5: Add barycentric coordinates and use tri->color for shading when available
  // Part 6: Fill in a SampleParams struct with psm, lsm and pass it to the tri->color function
  // Part 7: Pass in correct barycentric differentials dx and dy to tri->color for mipmapping


}
}




