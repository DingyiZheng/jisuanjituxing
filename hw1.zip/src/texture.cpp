#include "texture.h"
#include "CGL/color.h"

namespace CGL {

// Examines the enum parameters in sp and performs
// the appropriate sampling using the three helper functions below.
Color Texture::sample(const SampleParams &sp) {
  // Part 6: Fill in the functionality for sampling 
  //          nearest or bilinear in mipmap level 0, conditional on sp.psm
  // Part 7: Fill in full sampling (including trilinear), 
  //          conditional on sp.psm and sp.lsm
  Color color;
  if(sp.lsm == L_ZERO){
     if(sp.psm == P_NEAREST){
     color = sample_nearest(sp.uv,0);
     }
     if(sp.psm == P_LINEAR){
     color = sample_bilinear(sp.uv,0);
     }
  }else{

    float level = get_level(sp);
   // cout<<level<<"$"<<endl;
    int dlevel = floor(level);
    int ulevel = ceil(level);
    float k = level - dlevel;
    if(kMaxMipLevels<=level){
      level = kMaxMipLevels;
      k = 0;
    }



    if(sp.lsm == L_NEAREST){
      if(k<0.5){
       /* if(sp.psm == P_LINEAR){
     color = sample_bilinear(sp.uv,dlevel);
     }else{
         color = sample_nearest(sp.uv,dlevel);
       }*/

       color = sample_nearest(sp.uv,dlevel);
      }else{
       color = sample_nearest(sp.uv,ulevel);
      }

    }
    if(sp.lsm == L_LINEAR){
      color = k*sample_bilinear(sp.uv,ulevel)+(1-k)*sample_bilinear(sp.uv,dlevel);
     

    } 
  }

  return color;
}

// Given sp.du and sp.dv, returns the appropriate mipmap
// level to use for L_NEAREST or L_LINEAR filtering.
float Texture::get_level(const SampleParams &sp) {
  // Part 7: Fill this in.


  
  //float L = max(sqrt((ddu1*ddu1 + ddv1*ddv1)),sqrt( ddu2*ddu2 + ddv2*ddv2 ));
   // float L = max(sqrt((   sp.du[0]*sp.du[0]*mipmap[0].height*mipmap[0].height   +    sp.dv[0]*sp.dv[0]*mipmap[0].width*mipmap[0].width   )),sqrt(    sp.du[1]*sp.du[1]*mipmap[0].height*mipmap[0].height    +    sp.dv[1]*sp.dv[1]*mipmap[0].width*mipmap[0].width    ));
  float L = min(sqrt((   sp.du[0]*sp.du[0]*mipmap[0].width*mipmap[0].width   +    sp.dv[0]*sp.dv[0]*mipmap[0].height*mipmap[0].height   ))*0.4,sqrt(    sp.du[1]*sp.du[1]*mipmap[0].width*mipmap[0].width    +    sp.dv[1]*sp.dv[1]*mipmap[0].height*mipmap[0].height    )*0.4);
  //float a1=sqrt((   sp.du[0]*sp.du[0]*mipmap[0].width*mipmap[0].width   +    sp.dv[0]*sp.dv[0]*mipmap[0].height*mipmap[0].height   ));
  //float a2=sqrt(    sp.du[1]*sp.du[1]*mipmap[0].width*mipmap[0].width    +    sp.dv[1]*sp.dv[1]*mipmap[0].height*mipmap[0].height    );
  //cout <<"a1: "<<a1<<"a2: "<<a2<<endl; 
  //float L = max(sqrt((sp.du[0]*sp.du[0]*mipmap[0].width*mipmap[0].width + sp.dv[0]*sp.dv[0]*mipmap[0].height*mipmap[0].height)),sqrt( sp.du[1]*sp.du[1]*mipmap[0].width*mipmap[0].width + sp.dv[1]*sp.dv[1]*mipmap[0].height*mipmap[0].height ));
  //cout<<sp.du[0]*sp.du[0]*mipmap[0].width*mipmap[0].width<<"duwidth"<<endl;
    //cout<<sp.dv[0]*sp.dv[0]*mipmap[0].height*mipmap[0].height<<"dvheight"<<endl;


  return max(0.0,log(L)/log(2));
}

// Indexes into the level'th mipmap
// and returns the nearest pixel to (u,v)
Color Texture::sample_nearest(Vector2D uv, int level) {
  // Part 6: Fill this in.
  const MipLevel& map = mipmap[level];
  float x = round(uv[0]*map.width);
  float y = round(uv[1]*map.height);

  Color color;
  color.r = map.texels[4*(y*map.width+x)]/255.0;
  color.g = map.texels[4*(y*map.width+x)+1]/255.0;
  color.b = map.texels[4*(y*map.width+x)+2]/255.0;
  color.a = map.texels[4*(y*map.width+x)+3]/255.0;


  return color;
}

// Indexes into the level'th mipmap
// and returns a bilinearly weighted combination of
// the four pixels surrounding (u,v)
Color Texture::sample_bilinear(Vector2D uv, int level) {
  // Part 6: Fill this in.
  //const Texture& map = mipmap[level];
  //color = map[y*w+x];
  //return Color();
  const MipLevel& map = mipmap[level];
  float x = uv[0]*map.width;
  float y = uv[1]*map.height;
  float x1 = floor(uv[0]*map.width);
  //float x2 = ceil(uv[0]*map.width);
  float y1 = floor(uv[1]*map.height);
  //float theta = (x - x1);
  //float gama = (y - y1);
 float theta = (x1+1-x);
 float gama = (y1+1-y);
 width=map.width;
 height=map.height;
  //float y2 = ceil(uv[1]*map.height);


  Color color;
  color.r = (theta*gama*map.texels[4*(y1*width+x1)] + theta*(1-gama)*map.texels[4*(y1*width+x1+1)] + gama*(1-theta)*map.texels[4*((y1+1)*width+x1)] + (1-gama)*(1-theta)*map.texels[4*((y1+1)*width+x1+1)])/255.0;
  color.g = (theta*gama*map.texels[4*(y1*width+x1)+1] + theta*(1-gama)*map.texels[4*(y1*width+x1+1)+1] + gama*(1-theta)*map.texels[4*((y1+1)*width+x1)+1] + (1-gama)*(1-theta)*map.texels[4*((y1+1)*width+x1+1)+1])/255.0;
  color.b = (theta*gama*map.texels[4*(y1*width+x1)+2] + theta*(1-gama)*map.texels[4*(y1*width+x1+1)+2] + gama*(1-theta)*map.texels[4*((y1+1)*width+x1)+2] + (1-gama)*(1-theta)*map.texels[4*((y1+1)*width+x1+1)+2])/255.0;
  color.a = (theta*gama*map.texels[4*(y1*width+x1)+3] + theta*(1-gama)*map.texels[4*(y1*width+x1+1)+3] + gama*(1-theta)*map.texels[4*((y1+1)*width+x1)+3] + (1-gama)*(1-theta)*map.texels[4*((y1+1)*width+x1+1)+3])/255.0;


  return color;
}



/****************************************************************************/



inline void uint8_to_float(float dst[4], unsigned char *src) {
  uint8_t *src_uint8 = (uint8_t *)src;
  dst[0] = src_uint8[0] / 255.f;
  dst[1] = src_uint8[1] / 255.f;
  dst[2] = src_uint8[2] / 255.f;
  dst[3] = src_uint8[3] / 255.f;
}

inline void float_to_uint8(unsigned char *dst, float src[4]) {
  uint8_t *dst_uint8 = (uint8_t *)dst;
  dst_uint8[0] = (uint8_t)(255.f * max(0.0f, min(1.0f, src[0])));
  dst_uint8[1] = (uint8_t)(255.f * max(0.0f, min(1.0f, src[1])));
  dst_uint8[2] = (uint8_t)(255.f * max(0.0f, min(1.0f, src[2])));
  dst_uint8[3] = (uint8_t)(255.f * max(0.0f, min(1.0f, src[3])));
}

void Texture::generate_mips(int startLevel) {

  // make sure there's a valid texture
  if (startLevel >= mipmap.size()) {
    std::cerr << "Invalid start level";
  }

  // allocate sublevels
  int baseWidth = mipmap[startLevel].width;
  int baseHeight = mipmap[startLevel].height;
  int numSubLevels = (int)(log2f((float)max(baseWidth, baseHeight)));

  numSubLevels = min(numSubLevels, kMaxMipLevels - startLevel - 1);
  mipmap.resize(startLevel + numSubLevels + 1);

  int width = baseWidth;
  int height = baseHeight;
  for (int i = 1; i <= numSubLevels; i++) {

    MipLevel &level = mipmap[startLevel + i];

    // handle odd size texture by rounding down
    width = max(1, width / 2);
    //assert (width > 0);
    height = max(1, height / 2);
    //assert (height > 0);

    level.width = width;
    level.height = height;
    level.texels = vector<unsigned char>(4 * width * height);
  }

  // create mips
  int subLevels = numSubLevels - (startLevel + 1);
  for (int mipLevel = startLevel + 1; mipLevel < startLevel + subLevels + 1;
       mipLevel++) {

    MipLevel &prevLevel = mipmap[mipLevel - 1];
    MipLevel &currLevel = mipmap[mipLevel];

    int prevLevelPitch = prevLevel.width * 4; // 32 bit RGBA
    int currLevelPitch = currLevel.width * 4; // 32 bit RGBA

    unsigned char *prevLevelMem;
    unsigned char *currLevelMem;

    currLevelMem = (unsigned char *)&currLevel.texels[0];
    prevLevelMem = (unsigned char *)&prevLevel.texels[0];

    float wDecimal, wNorm, wWeight[3];
    int wSupport;
    float hDecimal, hNorm, hWeight[3];
    int hSupport;

    float result[4];
    float input[4];

    // conditional differentiates no rounding case from round down case
    if (prevLevel.width & 1) {
      wSupport = 3;
      wDecimal = 1.0f / (float)currLevel.width;
    } else {
      wSupport = 2;
      wDecimal = 0.0f;
    }

    // conditional differentiates no rounding case from round down case
    if (prevLevel.height & 1) {
      hSupport = 3;
      hDecimal = 1.0f / (float)currLevel.height;
    } else {
      hSupport = 2;
      hDecimal = 0.0f;
    }

    wNorm = 1.0f / (2.0f + wDecimal);
    hNorm = 1.0f / (2.0f + hDecimal);

    // case 1: reduction only in horizontal size (vertical size is 1)
    if (currLevel.height == prevLevel.height) {
      //assert (currLevel.height == 1);

      for (int i = 0; i < currLevel.width; i++) {
        wWeight[0] = wNorm * (1.0f - wDecimal * i);
        wWeight[1] = wNorm * 1.0f;
        wWeight[2] = wNorm * wDecimal * (i + 1);

        result[0] = result[1] = result[2] = result[3] = 0.0f;

        for (int ii = 0; ii < wSupport; ii++) {
          uint8_to_float(input, prevLevelMem + 4 * (2 * i + ii));
          result[0] += wWeight[ii] * input[0];
          result[1] += wWeight[ii] * input[1];
          result[2] += wWeight[ii] * input[2];
          result[3] += wWeight[ii] * input[3];
        }

        // convert back to format of the texture
        float_to_uint8(currLevelMem + (4 * i), result);
      }

      // case 2: reduction only in vertical size (horizontal size is 1)
    } else if (currLevel.width == prevLevel.width) {
      //assert (currLevel.width == 1);

      for (int j = 0; j < currLevel.height; j++) {
        hWeight[0] = hNorm * (1.0f - hDecimal * j);
        hWeight[1] = hNorm;
        hWeight[2] = hNorm * hDecimal * (j + 1);

        result[0] = result[1] = result[2] = result[3] = 0.0f;
        for (int jj = 0; jj < hSupport; jj++) {
          uint8_to_float(input, prevLevelMem + prevLevelPitch * (2 * j + jj));
          result[0] += hWeight[jj] * input[0];
          result[1] += hWeight[jj] * input[1];
          result[2] += hWeight[jj] * input[2];
          result[3] += hWeight[jj] * input[3];
        }

        // convert back to format of the texture
        float_to_uint8(currLevelMem + (currLevelPitch * j), result);
      }

      // case 3: reduction in both horizontal and vertical size
    } else {

      for (int j = 0; j < currLevel.height; j++) {
        hWeight[0] = hNorm * (1.0f - hDecimal * j);
        hWeight[1] = hNorm;
        hWeight[2] = hNorm * hDecimal * (j + 1);

        for (int i = 0; i < currLevel.width; i++) {
          wWeight[0] = wNorm * (1.0f - wDecimal * i);
          wWeight[1] = wNorm * 1.0f;
          wWeight[2] = wNorm * wDecimal * (i + 1);

          result[0] = result[1] = result[2] = result[3] = 0.0f;

          // convolve source image with a trapezoidal filter.
          // in the case of no rounding this is just a box filter of width 2.
          // in the general case, the support region is 3x3.
          for (int jj = 0; jj < hSupport; jj++)
            for (int ii = 0; ii < wSupport; ii++) {
              float weight = hWeight[jj] * wWeight[ii];
              uint8_to_float(input, prevLevelMem +
                                        prevLevelPitch * (2 * j + jj) +
                                        4 * (2 * i + ii));
              result[0] += weight * input[0];
              result[1] += weight * input[1];
              result[2] += weight * input[2];
              result[3] += weight * input[3];
            }

          // convert back to format of the texture
          float_to_uint8(currLevelMem + currLevelPitch * j + 4 * i, result);
        }
      }
    }
  }
}

}