#include "bvh.h"

#include "CGL/CGL.h"
#include "static_scene/triangle.h"

#include <iostream>
#include <stack>

using namespace std;

namespace CGL { namespace StaticScene {

BVHAccel::BVHAccel(const std::vector<Primitive *> &_primitives,
                   size_t max_leaf_size) {

  root = construct_bvh(_primitives, max_leaf_size);

}

BVHAccel::~BVHAccel() {
  if (root) delete root;
}

BBox BVHAccel::get_bbox() const {
  return root->bb;
}

void BVHAccel::draw(BVHNode *node, const Color& c) const {
  if (node->isLeaf()) {
    for (Primitive *p : *(node->prims))
      p->draw(c);
  } else {
    draw(node->l, c);
    draw(node->r, c);
  }
}

void BVHAccel::drawOutline(BVHNode *node, const Color& c) const {
  if (node->isLeaf()) {
    for (Primitive *p : *(node->prims))
      p->drawOutline(c);
  } else {
    drawOutline(node->l, c);
    drawOutline(node->r, c);
  }
}

BVHNode *BVHAccel::construct_bvh(const std::vector<Primitive*>& prims, size_t max_leaf_size) {
  
  // TODO Part 2, task 1:
  // Construct a BVH from the given vector of primitives and maximum leaf
  // size configuration. The starter code build a BVH aggregate with a
  // single leaf node (which is also the root) that encloses all the
  // primitives.

  BBox centroid_box, bbox;

  for (Primitive *p : prims) {
    BBox bb = p->get_bbox();
    bbox.expand(bb);
    Vector3D c = bb.centroid();
    centroid_box.expand(c);
  }

  // You'll want to adjust this code.
  // Right now we just return a single node containing all primitives.
  BVHNode *node = new BVHNode(bbox);
  node->prims = new vector<Primitive *>(prims);
  //return node;
  

  if(prims.size()<= max_leaf_size){//=
    node->l = NULL;
    node->r = NULL;
  }else{
   
    int axis = 0;
    if(bbox.extent.x>=bbox.extent.y&&bbox.extent.x>=bbox.extent.z){
      axis = 0;
    }
    else if(bbox.extent.y >= bbox.extent.x && bbox.extent.y >= bbox.extent.z){
      axis = 1;
    }
    else{
      axis = 2;
    }
    vector<Primitive *> left  = vector<Primitive *>();
    vector<Primitive *> right = vector<Primitive *>();
    double splitpoint = (centroid_box.max[axis] + centroid_box.min[axis])/2.0;
   // double splitpoint = (bbox.max[axis] + bbox.min[axis])/2.0;
    for(Primitive *p : prims){
      Vector3D center = p->get_bbox().centroid();
      if(splitpoint>= center[axis]){
        left.push_back(p);
      }
      else{
        right.push_back(p);
      }
    }
    if(left.size()==0){
      node->l = NULL;
    }
    if(right.size()==0){
      node->r = NULL;
    }
    if(left.size()>0){
      node->l = construct_bvh(left,max_leaf_size);
    }
    if(right.size()>0){
      node->r = construct_bvh(right,max_leaf_size);
    }

    return node;

  }


   
}


bool BVHAccel::intersect(const Ray& ray, BVHNode *node) const {

  // TODO Part 2, task 3:
  // Implement BVH intersection.
  // Currently, we just naively loop over every primitive.

  /*for (Primitive *p : *(root->prims)) {
    total_isects++;
    if (p->intersect(ray)) 
      return true;
  }
  return false;*/
  if(node==NULL){return false;}
  if(node->prims->size()==0){return false;}
  double tmin = ray.min_t;
  double tmax = ray.max_t;

    if(!(node->bb.intersect(ray,tmin,tmax))){
    return false;
  }else{
    if(node->isLeaf()){
       for (Primitive *p : *(node->prims)) {
       total_isects++;
      if (p->intersect(ray)) {
        total_isects++;
        return true;
      }
      
      }//for

    }else{
      bool b1 = intersect(ray,node->l);
      bool b2 = intersect(ray,node->r);
      return b1||b2;


      //return (intersect(ray,node->l)|| intersect(ray,node->r));
     

    }

  }

}

bool BVHAccel::intersect(const Ray& ray, Intersection* i, BVHNode *node) const {

  // TODO Part 2, task 3:
  // Implement BVH intersection.
  // Currently, we just naively loop over every primitive.
/*
  bool hit = false;
  for (Primitive *p : *(root->prims)) {
    total_isects++;
    if (p->intersect(ray, i)) 
      hit = true;
  }
  return hit;*/
    if(node==NULL){return false;}
  if(node->prims->size()==0){return false;}
  double tmin = ray.min_t;
  double tmax = ray.max_t;

    if(!(node->bb.intersect(ray,tmin,tmax))){
    return false;
  }else{
    if(node->isLeaf()){
      bool hit = false;
      for (Primitive *p : *(node->prims)) {
       total_isects++;
      if (p->intersect(ray,i)) {
        hit = true;
        //total_isects++;
       // return true;
        
      }
      
      }//for
     return hit;
    //  return false;

    }else{
     // return (intersect(ray,i,node->l)|| intersect(ray,i,node->r));
      bool b1 = intersect(ray,i,node->l);
      bool b2 = intersect(ray,i,node->r);
      return b1||b2;
      
    }

  }

}

}  // namespace StaticScene
}  // namespace CGL
